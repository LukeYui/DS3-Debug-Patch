The debug menu from Dark Souls III, note that some features are broken. Online has been disabled for the purpose of use, but this is to just to prevent bans; Any online use of this menu is extremely limited.

[USE]

Select = Show/Hide menu
RT + Right stick = Resize menu
RT + Left stick = Move menu
L3 + A = Freeze/Unfreeze camera

[INSTALLATION]

Simply drag and drop "d3d11.dll" into your DarkSoulsIII/Game directory (where your .exe is located)

[UNINSTALLATION]

Delete "d3d11.dll" from your DarkSoulsIII/Game directory.

[CREDITS]

Special thanks to Pav for helping me fix crashes/restore some hidden menus, and katalash for general code advice